import cv2
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk, ImageDraw
from ultralytics import YOLO
import time

# --- Folders Setup ---
os.makedirs("input", exist_ok=True)
os.makedirs("screenshots", exist_ok=True)

# --- Load YOLO Model ---
try:
    model = YOLO("yolov8n.pt")
except Exception as e:
    print(f"Error: {e}")

class ModernDashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Surveillance Dashboard v2.0")
        self.root.geometry("1100x850")
        self.root.configure(bg="#0f172a") # Deep Space Blue Background

        # --- Sidebar / Control Panel ---
        self.sidebar = tk.Frame(self.root, bg="#1e293b", width=250)
        self.sidebar.pack(side="left", fill="y")

        self.logo_label = tk.Label(self.sidebar, text="AI VISION", fg="#38bdf8", 
                                  bg="#1e293b", font=("Impact", 28))
        self.logo_label.pack(pady=40)

        # Style for Buttons
        style = ttk.Style()
        style.theme_use('clam')
        
        # Creating Custom Navigation Buttons
        self.create_nav_btn("🔴 LIVE FEED", "#ef4444", self.start_live)
        self.create_nav_btn("🎥 VIDEO ANALYTICS", "#3b82f6", self.start_video)
        self.create_nav_btn("🖼️ IMAGE SCAN", "#10b981", self.start_image)
        
        self.exit_btn = tk.Button(self.sidebar, text="EXIT SYSTEM", command=self.root.quit,
                                 bg="#475569", fg="white", bd=0, font=("Arial", 10, "bold"),
                                 width=20, height=2, cursor="hand2")
        self.exit_btn.pack(side="bottom", pady=30)

        # --- Main Viewport ---
        self.main_frame = tk.Frame(self.root, bg="#0f172a")
        self.main_frame.pack(side="right", expand=True, fill="both", padx=20)

        self.header = tk.Label(self.main_frame, text="System Status: Active Monitoring", 
                              fg="#94a3b8", bg="#0f172a", font=("Segoe UI", 12))
        self.header.pack(pady=(20, 10), anchor="w")

        # The Monitor Screen (Black Border with Glow Effect)
        self.screen_frame = tk.Frame(self.main_frame, bg="#38bdf8", padx=2, pady=2)
        self.screen_frame.pack(expand=True)

        self.display = tk.Label(self.screen_frame, bg="#000000", width=800, height=500)
        self.display.pack()

        # Footer / Info
        self.footer = tk.Label(self.main_frame, text="YOLOv8 Real-time Object Tracking Engine", 
                              fg="#475569", bg="#0f172a", font=("Segoe UI", 9, "italic"))
        self.footer.pack(pady=20)

        self.is_streaming = False

    def create_nav_btn(self, text, color, command):
        """Helper to create professional sidebar buttons"""
        btn = tk.Button(self.sidebar, text=text, command=command,
                        bg=color, fg="white", bd=0, font=("Segoe UI", 11, "bold"),
                        width=22, height=2, cursor="hand2", activebackground="#ffffff")
        btn.pack(pady=10, padx=20)

    def process_and_show(self, frame):
        """Convert OpenCV BGR to Tkinter Image"""
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        img = img.resize((850, 500), Image.Resampling.LANCZOS)
        img_tk = ImageTk.PhotoImage(image=img)
        self.display.img_tk = img_tk
        self.display.config(image=img_tk)

    def start_live(self):
        self.is_streaming = True
        cap = cv2.VideoCapture(0)
        while self.is_streaming:
            ret, frame = cap.read()
            if not ret: break
            
            results = model.track(frame, persist=True, verbose=False)
            res_frame = results[0].plot()
            
            self.process_and_show(res_frame)
            self.root.update()
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.is_streaming = False
        cap.release()

    def start_video(self):
        file_path = filedialog.askopenfilename(initialdir="input", title="Select Video")
        if not file_path: return
        
        cap = cv2.VideoCapture(file_path)
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret: break
            results = model.track(frame, persist=True, verbose=False)
            self.process_and_show(results[0].plot())
            self.root.update()
        cap.release()

    def start_image(self):
        file_path = filedialog.askopenfilename(initialdir="input", title="Select Image")
        if not file_path: return
        
        frame = cv2.imread(file_path)
        results = model(frame)
        res_frame = results[0].plot()
        
        # Save detection automatically
        cv2.imwrite(f"screenshots/detect_{int(time.time())}.jpg", res_frame)
        self.process_and_show(res_frame)
        messagebox.showinfo("Result", "Image Processed & Saved in 'screenshots' folder.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ModernDashboard(root)
    root.mainloop()