import cv2
import numpy as np
import os
import time
from collections import defaultdict

# --- Dependencies Check ---
try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
except ImportError:
    YOLO_AVAILABLE = False
    print("[WARNING] ultralytics not installed. Run: pip install ultralytics")

# --- Folder Setup (As per your image) ---
os.makedirs("screenshots", exist_ok=True)
os.makedirs("input", exist_ok=True)
os.makedirs("output", exist_ok=True)

# --- Load YOLO Model (As per your image) ---
if YOLO_AVAILABLE:
    print("[*] Loading YOLOv8 model...")
    # Auto-downloads model if not present
    model = YOLO("yolov8n.pt")
    print("[✓] YOLOv8 model loaded successfully")
else:
    model = None

# --- Simple Tracker (SORT-like logic) ---
class SimpleTracker:
    def __init__(self):
        self.center_points = {}
        self.id_count = 0

    def update(self, objects_rect):
        objects_bbs_ids = []
        for rect in objects_rect:
            x, y, w, h = rect
            cx = (x + x + w) // 2
            cy = (y + y + h) // 2

            same_object_detected = False
            for id, pt in self.center_points.items():
                dist = np.hypot(cx - pt[0], cy - pt[1])
                if dist < 35:
                    self.center_points[id] = (cx, cy)
                    objects_bbs_ids.append([x, y, w, h, id])
                    same_object_detected = True
                    break

            if not same_object_detected:
                self.center_points[self.id_count] = (cx, cy)
                objects_bbs_ids.append([x, y, w, h, self.id_count])
                self.id_count += 1

        # Clean up old points
        new_center_points = {}
        for obj_bb_id in objects_bbs_ids:
            _, _, _, _, object_id = obj_bb_id
            center = self.center_points[object_id]
            new_center_points[object_id] = center
        self.center_points = new_center_points.copy()
        return objects_bbs_ids

# --- Main Logic ---
def main():
    if model is None:
        print("Error: Model not loaded. Please install dependencies.")
        return

    tracker = SimpleTracker()
    cap = cv2.VideoCapture(0) # 0 for Webcam

    print("\n[INFO] Starting Stream...")
    print("[INFO] Press 'q' to Quit, 's' to save Screenshot.")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Object Detection
        results = model(frame, stream=True, verbose=False)
        detections = []
        for r in results:
            boxes = r.boxes
            for box in boxes:
                x1, y1, x2, y2 = box.xyxy[0]
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                w, h = x2 - x1, y2 - y1
                conf = float(box.conf[0])
                if conf > 0.5:
                    detections.append([x1, y1, w, h])

        # Object Tracking
        boxes_ids = tracker.update(detections)
        for box_id in boxes_ids:
            x, y, w, h, id = box_id
            cv2.putText(frame, f"ID: {id}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        cv2.imshow("YOLOv8 Real-time Tracking", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('s'):
            # Save to the folder from your image
            img_path = f"screenshots/frame_{int(time.time())}.jpg"
            cv2.imwrite(img_path, frame)
            print(f"[✓] Screenshot saved to {img_path}")

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()